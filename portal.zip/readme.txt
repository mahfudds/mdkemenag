Sistem Informasi Sekolah JIBAS 
Hak cipta (C) 2009 Yayasan Indonesia Membaca
============================================

KEBUTUHAN SISTEM
----------------

Untuk PRODUCTION: Server yang digunakan khusus untuk JIBAS

1. Processor setara Intel i3 atau lebih 

2. Memory 8 GB atau lebih

3. Harddisk 1 TB (7200 rpm) atau lebih

4. Sistem Operasi Windows 7, 8, 10 atau lebih baru,
   Linux varian Debian (UBuntu, Mint) dan Linux varian RedHat (RHEL, CentOS, ClearOS)
   
Untuk TESTING: PC untuk ujicoba, pratayang dan demo JIBAS

1. Processor setara Dual Core atau lebih 

2. Memory 4 GB atau lebih

3. Harddisk 1 TB (7200 rpm) atau lebih

4. Sistem Operasi Windows 7, 8, 10 atau lebih baru,
   Linux varian Debian (UBuntu, Mint) dan Linux varian RedHat (RHEL, CentOS, ClearOS)

NOTE: Jalankan JIBAS Configuration Wizard untuk mengatur konfigurasi yang digunakan.

PENDAHULUAN
-----------
1. Sistem Informasi Sekolah JIBAS dapat dibuka menggunakn web browser dengan halaman http://localhost/jibas/.
   Disarankan menggunakan web browser Mozilla Firefox atau Google Chrome.

2. Untuk masuk pertama kali ke dalam aplikasi, gunakan login admin: "jibas" sebagai username dan "password" sebagai password.

3. Atur kembali logo dan indentitas sekolah di c:\YIM\JIBAS\xampp\htdocs\jibas\include\school.config.php

4. Atur kembali lokasi dan alamat aplikasi di c:\YIM\JIBAS\xampp\htdocs\jibas\include\application.config.php


INFORMASI & DUKUNGAN TEKNIS
---------------------------
Informasi & Update    http://www.jibas.net
Forum Diskusi         https://www.facebook.com/groups/forumjibas/
Facebook              https://www.facebook.com/infojibas