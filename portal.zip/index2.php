<script language="javascript">
document.location.href = "jibas";
</script>